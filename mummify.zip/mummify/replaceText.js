/*var infocus =false;
$('input, textarea').focus(function(){
  infocus = $(this).attr('id');
});
function replaceText(selectedText,texttoreplace){
  $("#"+infocus).val(function () {
    return $(this).val().replace(selectedText, texttoreplace);
});

}*/
